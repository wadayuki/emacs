Muse is a tool for easily authoring and publishing documents.  It
allows for rapid prototyping of hyperlinked text, which may then be
exported to multiple output formats, such as HTML, LaTeX, and Texinfo.

The markup rules used by Muse are intended to be very friendly to
people familiar with Emacs.  See the included manual for more
information.
